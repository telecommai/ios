//
//  XLFormSwitchCell.h
//  XLForm ( https://github.com/xmartlabs/XLForm )
//
//  Copyright (c) 2014 Xmartlabs ( http://xmartlabs.com )
//
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

#import "XLFormRowDescriptor.h"

#ifdef NEED_FRAMEWORK
#import <IOSMobileCompsFramework/XLFormSwitchCell.h>
#import <IOSMobileCompsFramework/FormSwitch.h.h>

#else
#import "XLFormSwitchCell.h"
#import "FormSwitch.h"
#endif

@implementation XLFormSwitchCell

#pragma mark - XLFormDescriptorCell

- (void)configure
{
    [super configure];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    self.accessoryView = [[FormSwitch alloc] init];//[[UISwitch alloc] init];
    [self.switchControl addTarget:self action:@selector(valueChanged) forControlEvents:UIControlEventValueChanged];
}

- (void)update
{
    [super update];
    self.textLabel.text = self.rowDescriptor.title;
//    self.switchControl.on = [self.rowDescriptor.value boolValue];
    
    self.switchControl.dataSetComponent = self.rowDescriptor.dataSetComponent;
    self.switchControl.dataSetID = self.rowDescriptor.dataSetID;
    self.switchControl.dataSetColID = self.rowDescriptor.dataSetColID;
    if(self.rowDescriptor.internalDataSetID){
        self.switchControl.internalDataSetID = self.rowDescriptor.internalDataSetID;
        self.switchControl.isUserInternalDataSetID = YES;
    }

    self.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    self.textLabel.textColor  = self.rowDescriptor.disabled ? [UIColor grayColor] : [UIColor blackColor];
//    self.switchControl.enabled = !self.rowDescriptor.disabled;
}

- (FormSwitch *)switchControl
{
    return (FormSwitch *)self.accessoryView;
}

- (void)valueChanged
{
    self.rowDescriptor.value = @(self.switchControl.on);
}

@end
