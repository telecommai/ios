//
//  FormCard.m
//  XLFormTest
//
//  Created by Javor on 14/11/13.
//  Copyright (c) 2014年 Javor. All rights reserved.
//

#import "FormCard.h"
#import "XLForm.h"
#import "FormAppUtils.h"

const int C_FormLabel         = 0;
const int C_FormTextField     = 1;
const int C_FormSpinner       = 2;
const int C_FormNumberField   = 3;
const int C_FormCheckBox      = 4;
const int C_FormDatePicker    = 5;
const int C_FormHelpField     = 7;
const int C_FormComboBox      = 6;
const int C_FormTextAreaField = 8;
const int C_FormDateTime      = 14;
const int C_FormForm          = 15;

@interface FormCard(){
    XLFormViewController *_formViewController;
}
@end

@implementation FormCard

@synthesize dataSetComponent = _dataSetComponent;
@synthesize dataSet = _dataSet;
@synthesize dataSetID = _dataSetID;
@synthesize columnModel = _columnModel;
@synthesize x=_x,y=_y,width=_width,height=_height,percentWidth=_percentWidth,percentHeight=_percentHeight;
@synthesize scriptObject = _scriptObject;

-(instancetype)init{
    self = [super init];
    if(self){
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

-(void)creationComplete{
    if(_formViewController) return;
    //初始化XLFormViewController
    _formViewController = [[XLFormViewController alloc] init];
    
    //给formFrame赋值
    CGRect formFrame = CGRectMake([_x intValue], [_y intValue], [_width intValue], [_height intValue]);
    _formViewController.formFrame = formFrame;
    
    //初始化XLFormDescriptor
    XLFormDescriptor *form = [XLFormDescriptor formDescriptor];
    
    NSMutableArray *columnsArray = _columnModel.children;
    if(columnsArray == nil) return;
    XLFormSectionDescriptor *section = nil;
    for(DataComponent *dc in columnsArray){
        //根据ColumnGroup创建XLFormSectionDescriptor或者XLFormRowDescriptor
        if([dc isKindOfClass:[ColumnGroup class]]){
            ColumnGroup *columnGroup = (ColumnGroup *)dc;
            //如果是section则生成XLFormSectionDescriptor
//            if([columnGroup.formType isEqualToString:@"section"]){
            section = [XLFormSectionDescriptor formSectionWithTitle:columnGroup.headerText];
            [form addFormSection:section];
            //根据Column创建XLFormRowDescriptor
            for(DataComponent *childrenDC in columnGroup.children){
                if([childrenDC isKindOfClass:[Column class]]){
                    Column *column = (Column *)childrenDC;
                    XLFormRowDescriptor *row = [self createFormRowWithColumn:column];
                    row.dataSetComponent = self.dataSetComponent;
                    row.dataSetID = self.dataSetID;
                    row.dataSetColID = column.dataSetColID;
                    row.internalDataSetID = column.internalDataSetID;
                    row.title = column.headerText;
                    row.formID = column.formID;
                    [section addFormRow:row];
                }
            }
//            }
            //如果是跳转页面则生成XLFormRowDescriptor
//            else if([columnGroup.formType isEqualToString:@"cell"]){
//                //如果没有section 先创建section
//                if(section == nil){
//                    section = [XLFormSectionDescriptor formSectionWithTitle:@""];
//                    [form addFormSection:section];
//                }
//                //创建新页面的ColumnModel
//                ColumnModel *childColumnModel = [[ColumnModel alloc] init];

            .//                //将该columnGroup的类别改成section
//                columnGroup.formType = @"section";
//                //创建跳转后的界面
//                FormCard *formCard = [[FormCard alloc] init];
//                formCard.columnModel = childColumnModel;
//                formCard.dataSetComponent = self.dataSetComponent;
//                formCard.x = self.x;
//                formCard.y = self.y;
//                formCard.width = self.width;
//                formCard.height = self.height;
//                XLFormRowDescriptor *row = [XLFormRowDescriptor formRowDescriptorWithTag:columnGroup.headerText rowType:XLFormRowDescriptorTypeButton title:columnGroup.headerText];
//                row.buttonView = formCard;
//                [section addFormRow:row];
//            }
        }
    }
    _formViewController.form = form;
    [self addSubview:_formViewController.view];
    
    //脚本
    [FormAppUtils executeCompScripts:self andScriptContext:scriptContext andFunctionName:@"formContainerCreated" andThisObject:nil andArgs:nil];
}

-(void)setColumnModel:(ColumnModel *)aColumnModel{
    _columnModel = aColumnModel;
}

-(XLFormRowDescriptor *)createFormRowWithColumn:(Column *)column{
    int editorType = [column.editorType intValue];
    NSString *rowType;
    switch (editorType) {
        case C_FormLabel:
            rowType = XLFormRowDescriptorTypeButton;
            break;
        case C_FormTextField:
            rowType = XLFormRowDescriptorTypeText;
            break;
        case C_FormSpinner:
            rowType = XLFormRowDescriptorTypeStepCounter;
            break;
        case C_FormNumberField:
            rowType = XLFormRowDescriptorTypeText;
            break;
        case C_FormCheckBox:
            rowType = XLFormRowDescriptorTypeBooleanSwitch;
            break;
        case C_FormDatePicker:
            rowType = XLFormRowDescriptorTypeDateTimeInline;
            break;
        case C_FormComboBox:
            rowType = XLFormRowDescriptorTypeSelectorSegmentedControl;
            break;
        case C_FormTextAreaField:
            rowType = XLFormRowDescriptorTypeTextView;
            break;
        case C_FormForm:
            rowType = XLFormRowDescriptorTypeForm;
            break;
        default:
            rowType = XLFormRowDescriptorTypeText;
            break;
    }
    XLFormRowDescriptor *row = [XLFormRowDescriptor formRowDescriptorWithTag:column.pid rowType:rowType];
    return row;
}

-(void)setDataSet:(EFDataSet *)aDataSet{
    _dataSet =  aDataSet;
}

-(void)setDataSetComponent:(id)dsc{
    _dataSetComponent = dsc;
    
    if(self.dataSetComponent == nil) return;
    
    [self.dataSetComponent insertDMComponent:self];
}

-(BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event{
    return YES;
}

-(void)setParamValue:(id)value forElementKey:(NSString *)eKey {
    NSString *prefixChar  = [[eKey substringToIndex:1] uppercaseString];
    NSString *stuffString = [eKey substringFromIndex:1];
    NSString *setterStr = [NSString stringWithFormat:@"set%@%@:",prefixChar,stuffString];
    // 判断是否存在setter方法，防止设置未知属性造成的crash
    if ([self respondsToSelector:NSSelectorFromString(setterStr)]) {
        
        NSString *propertyName = eKey;
        [self setValue:value forKey:propertyName];
    }
    // 打印错误log
    else
        NSLog(@"wzf== 没有相应方法%@ %s(line:%d) ==>",setterStr, __func__,__LINE__);
}

-(void)dataSetChanged:(DataSetEvent *)dataSetEvent;
{
}

///////////////////////////////////////////////////////////
// IScriptObject methods Start
///////////////////////////////////////////////////////////

-(NSMutableDictionary *)getScriptObject{
    return _scriptObject;
}
-(void)setScriptObject:(NSMutableDictionary *)aScriptObject{
    _scriptObject = aScriptObject;
}

-(NSString *)getEventScriptForKey:(NSString *)aKey{
    if(_scriptObject == nil) return nil;
    return [_scriptObject objectForKey:aKey];
}
-(void)setEventScript:(NSString *)script forKey:(NSString *)aKey{
    if(_scriptObject == nil) _scriptObject = [[NSMutableDictionary alloc]init];
    [_scriptObject setObject:script forKey:aKey];
    
}

-(NSMutableDictionary *)getScriptContext{
    return scriptContext;
}
-(void)setScriptContext:(NSMutableDictionary *)aContext{
    scriptContext = aContext;
}

///////////////////////////////////////////////////////////
// IScriptObject methods End
///////////////////////////////////////////////////////////

@end
