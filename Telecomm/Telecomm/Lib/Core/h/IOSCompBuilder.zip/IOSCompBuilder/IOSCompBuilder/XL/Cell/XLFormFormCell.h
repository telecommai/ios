//
//  XLFormFormCell.h
//  IOSCompBuilder
//
//  Created by Javor on 14/11/28.
//  Copyright (c) 2014年 Javor. All rights reserved.
//

#import "XLFormBaseCell.h"

/*
 * 打开表单的Cell
 * Javor
 */
@interface XLFormFormCell : XLFormBaseCell

@end
