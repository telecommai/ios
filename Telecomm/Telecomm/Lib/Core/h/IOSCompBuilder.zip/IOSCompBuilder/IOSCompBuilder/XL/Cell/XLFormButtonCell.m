//
//  XLFormButtonCell.m
//  XLForm ( https://github.com/xmartlabs/XLForm )
//
//  Copyright (c) 2014 Xmartlabs ( http://xmartlabs.com )
//
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

#import "XLFormRowDescriptor.h"
#import "XLFormButtonCell.h"
#import "FormCard.h"
#import "EnvironmentVariable.h"
#import "EFFrameUtil.h"

@implementation XLFormButtonCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    return [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
}


#pragma mark - XLFormDescriptorCell

-(void)configure
{
    [super configure];
}

-(void)update
{
    [super update];
    self.textLabel.text = self.rowDescriptor.title;
//    self.textLabel.textAlignment = self.rowDescriptor.buttonViewController ? NSTextAlignmentLeft : NSTextAlignmentCenter;
    self.textLabel.textAlignment = NSTextAlignmentLeft;
    if(self.rowDescriptor.buttonViewController || self.rowDescriptor.buttonView){
        self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }else{
        self.accessoryType = UITableViewCellAccessoryNone;
    }
    self.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    self.textLabel.textColor  = self.rowDescriptor.disabled ? [UIColor grayColor] : [UIColor blackColor];
    self.selectionStyle = self.rowDescriptor.disabled ? UITableViewCellSelectionStyleNone : UITableViewCellSelectionStyleDefault;
}

-(void)formDescriptorCellDidSelectedWithFormController:(XLFormViewController *)controller
{
    BOOL hasAction = self.rowDescriptor.action.formBlock || self.rowDescriptor.action.formSelector;
    if (hasAction){
        if (self.rowDescriptor.action.formBlock){
            self.rowDescriptor.action.formBlock(self.rowDescriptor);
        }
        else{
            [controller performFormSeletor:self.rowDescriptor.action.formSelector withObject:self.rowDescriptor];
        }
    }
    else if (self.rowDescriptor.buttonViewController){
        if (controller.navigationController == nil || [self.rowDescriptor.buttonViewController isSubclassOfClass:[UINavigationController class]] || self.rowDescriptor.buttonViewControllerPresentationMode == XLFormPresentationModePresent){
            [controller presentViewController:[[self.rowDescriptor.buttonViewController alloc] init] animated:YES completion:nil];
        }
        else{
            [controller.navigationController pushViewController:[[self.rowDescriptor.buttonViewController alloc] init] animated:YES];
        }
    }
    //展示下级FormCard
    else if (self.rowDescriptor.buttonView){
        //创建一个UIViewController用于展示下级页面
        UIViewController *uiViewController = [[UIViewController alloc] init];
        [uiViewController.view addSubview:self.rowDescriptor.buttonView];
        if([[EnvironmentVariable getPlatform] isEqualToString:kPlatformTablet]){
            [EFFrameUtil pushNewView:self.rowDescriptor.buttonView animated:YES];
        }
        else if (controller.navigationController == nil || [self.rowDescriptor.buttonViewController isSubclassOfClass:[UINavigationController class]] || self.rowDescriptor.buttonViewControllerPresentationMode == XLFormPresentationModePresent){
            //如果是presentViewController 增加关闭按钮
            UIButton *closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
            [closeButton setTitle:@"关闭" forState:UIControlStateNormal];
            [closeButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
            closeButton.frame = CGRectMake(0, 22, 44, 44);
            [closeButton addTarget:self action:@selector(action_closePresentView:) forControlEvents:UIControlEventTouchUpInside];
            [uiViewController.view addSubview:closeButton];
            
            [controller presentViewController:uiViewController animated:YES completion:nil];
        }else{
            [controller.navigationController pushViewController:uiViewController animated:YES];
        }
        [((FormCard *)self.rowDescriptor.buttonView) creationComplete];
    }
}

-(void)action_closePresentView:(id)sender{
    UIButton *button = (UIButton *)sender;
    UIView *view = [button superview];
    id object = [view nextResponder];
    while (![object isKindOfClass:[UIViewController class]] && object != nil) {
        object = [object nextResponder];
    }
    UIViewController *uiViewController=(UIViewController*)object;
    [uiViewController dismissViewControllerAnimated:YES completion:nil];
}
@end
