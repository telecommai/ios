//
//  XLFormFormCell.m
//  IOSCompBuilder
//
//  Created by Javor on 14/11/28.
//  Copyright (c) 2014年 Javor. All rights reserved.
//

#import "XLFormFormCell.h"
#import "FormAppUtils.h"
#import "EnvironmentVariable.h"
#import "EFFrameUtil.h"

@implementation XLFormFormCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    return [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
}

#pragma mark - XLFormDescriptorCell

-(void)configure
{
    [super configure];
}

-(void)update
{
    [super update];
    self.textLabel.text = self.rowDescriptor.title;
//    self.textLabel.textAlignment = self.rowDescriptor.buttonViewController ? NSTextAlignmentLeft : NSTextAlignmentCenter;
    self.textLabel.textAlignment = NSTextAlignmentLeft;
    self.accessoryType = self.rowDescriptor.formID ? UITableViewCellAccessoryDisclosureIndicator: UITableViewCellAccessoryNone;
    self.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    self.textLabel.textColor  = self.rowDescriptor.disabled ? [UIColor grayColor] : [UIColor blackColor];
    self.selectionStyle = self.rowDescriptor.disabled ? UITableViewCellSelectionStyleNone : UITableViewCellSelectionStyleDefault;
}

-(void)formDescriptorCellDidSelectedWithFormController:(XLFormViewController *)controller
{
    //如果设置了表单ID 打开表单
    if(self.rowDescriptor.formID){
        //创建一个UIViewController用于展示下级页面
        UIViewController *uiViewController = [[UIViewController alloc] init];
        UIView *formView = [FormAppUtils generateFormView:self.rowDescriptor.formID];
        if(formView == nil) return;
        [uiViewController.view addSubview:formView];
        //如果是平板界面 直接push
        if([[EnvironmentVariable getPlatform] isEqualToString:kPlatformTablet]){
            [EFFrameUtil pushNewView:formView animated:YES];
        }
        else if (controller.navigationController == nil || self.rowDescriptor.buttonViewControllerPresentationMode == XLFormPresentationModePresent){
            //如果是presentViewController 增加关闭按钮
            UIButton *closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
            [closeButton setTitle:@"关闭" forState:UIControlStateNormal];
            [closeButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
            closeButton.frame = CGRectMake(0, 22, 44, 44);
            [closeButton addTarget:self action:@selector(action_closePresentView:) forControlEvents:UIControlEventTouchUpInside];
            [uiViewController.view addSubview:closeButton];
            uiViewController.view.backgroundColor = [UIColor whiteColor];
            [controller presentViewController:uiViewController animated:YES completion:nil];
        }else{
            [controller.navigationController pushViewController:uiViewController animated:YES];
        }
    }
}

-(void)action_closePresentView:(id)sender{
    UIButton *button = (UIButton *)sender;
    UIView *view = [button superview];
    id object = [view nextResponder];
    while (![object isKindOfClass:[UIViewController class]] && object != nil) {
        object = [object nextResponder];
    }
    UIViewController *uiViewController=(UIViewController*)object;
    [uiViewController dismissViewControllerAnimated:YES completion:nil];
}

@end
