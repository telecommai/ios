//
//  FormList.h
//  IOSCompBuilder
//
//  Created by Javor on 14/12/3.
//  Copyright (c) 2014年 Javor. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IUIComponent.h"
#import "DMComponent.h"
#import "IScriptObject.h"
#import "DataComponent.h"

@interface FormList : UIView<IUIComponent,DMComponent,IScriptObject>

@property(nonatomic, strong) DataComponent *dataComponent;

@end
