//
//  FormCard.h
//  XLFormTest
//
//  Created by Javor on 14/11/13.
//  Copyright (c) 2014年 Javor. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ColumnModel.h"
#import "ColumnGroup.h"
#import "Column.h"
#import "IUIComponent.h"
#import "DataSetComponent.h"
#import "DMComponent.h"
#import "DataComponent.h"
#import "IScriptObject.h"

@interface FormCard : UIView<IUIComponent,DMComponent,IScriptObject>{
    NSString *prototype;
    NSMutableDictionary *scriptContext;
}

@property(nonatomic, strong) ColumnModel *columnModel;
@property(nonatomic, strong) DataComponent *dataComponent;

@property(nonatomic, strong,getter = getScriptContext,setter = setScriptContext:) NSMutableDictionary *scriptObject;


@end
