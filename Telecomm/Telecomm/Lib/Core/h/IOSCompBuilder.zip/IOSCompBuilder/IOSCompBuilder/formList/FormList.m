//
//  FormList.m
//  IOSCompBuilder
//
//  Created by Javor on 14/12/3.
//  Copyright (c) 2014年 Javor. All rights reserved.
//

#import "FormList.h"

@interface FormList()<UITableViewDataSource,UITableViewDelegate>{
    UITableView *_formTableView;
}
@end

@implementation FormList

-(instancetype)init{
    self = [super init];
    if(self){
        
    }
    return self;
}

-(void)creationComplete{
    
}

@end
